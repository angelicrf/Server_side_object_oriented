﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Refahiyat_Angelique_Assignment_2.Models;
using Microsoft.AspNetCore.Mvc;
using Refahiyat_Angelique_Assignment_2.Models.DAL;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;

namespace Refahiyat_Angelique_Assignment_2.Controllers
{
    public class HomeController : Controller
    {

        private readonly IConfiguration configuration;
        public HomeController(IConfiguration config)
        {

            this.configuration = config;
        }
        public IActionResult Index()
        {
            return View();
        }

     
    
        public ActionResult page2(Person person)
        {

            //ViewBag.myValue = uName;
            //string connStr = configuration.GetConnectionString("MyConnStr");
            DALPerson dp = new DALPerson(configuration);
            int uID = dp.addUser(person);

            person.UID = uID;
            HttpContext.Session.SetString("uID", uID.ToString());
            string strUID = HttpContext.Session.GetString("uID");
            
            return View(person);
        }
        
        public IActionResult EditPerson()
        {
            int uID = Convert.ToInt32(HttpContext.Session.GetString("uID"));
            DALPerson dp = new DALPerson(configuration);
            Person person = dp.getPerson(uID);

            return View(person);
        }

        public IActionResult UpdateUser(Person person)
        {
            int uID = Convert.ToInt32(HttpContext.Session.GetString("uID"));
            person.UID = uID;

            DALPerson dp = new DALPerson(configuration);

            dp.UpdateUser(person);
            
            return View("Page2",person);

        }
        public IActionResult DeletePerson()
        {
            int uID = Convert.ToInt32(HttpContext.Session.GetString("uID"));
            DALPerson dp = new DALPerson(configuration);
            Person person = dp.getPerson(uID);
            dp.DeletePerson(uID);


            return View(person);
        }
       
    }
}
