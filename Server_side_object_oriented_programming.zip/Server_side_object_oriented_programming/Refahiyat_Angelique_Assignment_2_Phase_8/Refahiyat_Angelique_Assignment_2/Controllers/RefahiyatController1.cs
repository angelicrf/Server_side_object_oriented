﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Refahiyat_Angelique_Assignment_2.Models;
using Refahiyat_Angelique_Assignment_2.Models.DAL;
using Refahiyat_Angelique_Assignment_2.Controllers.DAL;

namespace Refahiyat_Angelique_Assignment_2.Controllers
{
    
    public class RefahiyatController1 : Controller
    {
       
        private readonly IConfiguration configuration;
        public RefahiyatController1(IConfiguration config)
        {
            this.configuration = config;

        }
        public IActionResult Index()
        {
            ViewBag.ShowLogInForm = true;
            return View();
        }
        public IActionResult EnterNewProduct()
        {

            if (!this.LogIn())
            {

                ViewBag.ShowLogInForm = true;
                ViewBag.LoginMessage = "login failed";


                return View("Index");
            }
            
            return View();
        }

        private bool LogIn()
        {
            if(HttpContext.Session.GetString("uID")==null)
            {
                return false;

            }
            else
            {
                return true;
            }

        }

        public IActionResult AddNewProduct(Products products)
        {

            DALProducts pd = new DALProducts(configuration);
            int pID = pd.AddNewProduct(products);

            
            products.PID = pID;
            HttpContext.Session.SetString("pID", pID.ToString());
            string strPID = HttpContext.Session.GetString("pID");

            return View(products);

        }




        public IActionResult LogIn(LogInCredentials lic)
        {
            DALPerson dp = new DALPerson(configuration);
            PersonShort ps = dp.CheckLogInCredentials(lic);
            if(ps == null)
            {
                ViewBag.ShowLogInForm = true;
                ViewBag.LoginMessage = "login failed";
            }
            else
            {
                HttpContext.Session.SetString("uID", ps.PersonID);
                HttpContext.Session.SetString("uFName", ps.FName); 
                ViewBag.UserFirstName = ps.FName;
            }
            return View("Index");
        }
        public IActionResult ShowAllProducts()
        {
            if (!this.LogIn())
            {

                ViewBag.ShowLogInForm = true;
                ViewBag.LoginMessage = "login failed";


                return View("Index");
            }


            DALProducts dp = new DALProducts(configuration);
            LinkedList<Products> allProds = dp.GetAllProducts();

            return View(allProds);
        }

        public IActionResult OneClickBuy(int PID)
        {
            string struID = HttpContext.Session.GetString("uID");
            if (!this.LogIn())
            {

                ViewBag.ShowLogInForm = true;
                ViewBag.LoginMessage = "login failed";


                return View("Index");
            }
            

            DALSalesTransaction dst = new DALSalesTransaction(configuration);
            dst.RecordTransaction(Convert.ToInt32(PID), Convert.ToInt32(struID));
            
            int manypuschaseproduct = 1;
            DALPerson person = new DALPerson(configuration);
            DALProducts dp = new DALProducts(configuration);
            
            Purchase purchase = new Purchase();
            purchase.pperson = person.getPerson(Convert.ToInt32(struID));
            purchase.pproducts = dp.getProduct(PID);
            Products products =dp.getProduct(PID);

            dp.UpdateInventory(PID, manypuschaseproduct * -1);
            
            return View(purchase);
        }
       
    }
}
