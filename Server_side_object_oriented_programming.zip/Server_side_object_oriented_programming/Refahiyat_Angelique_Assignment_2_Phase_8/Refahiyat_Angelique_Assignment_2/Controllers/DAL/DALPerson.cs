﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Refahiyat_Angelique_Assignment_2.Models;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;



namespace Refahiyat_Angelique_Assignment_2.Models.DAL
{
    public class DALPerson
    {
        private IConfiguration configuration;
        public DALPerson(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        public int addUser(Person person)
        {
            string connStr = configuration.GetConnectionString("MyConnStr");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
           
            string quary = "INSERT INTO [dbo].[Person] ([FName] ,[LName],[email],[phone],[address],[UserName]) VALUES(@FName,@LName,@email,@phone ,@address,@UserName) Select SCOPE_IDENTITY() as id;";
           
            SqlCommand cmd = new SqlCommand(quary, conn);
            cmd.Parameters.AddWithValue("@FName", person.UName);
            cmd.Parameters.AddWithValue("@LName", person.ULast);
            cmd.Parameters.AddWithValue("@email", person.UEmail);
            cmd.Parameters.AddWithValue("@phone", person.UPhone);
            cmd.Parameters.AddWithValue("@address", person.UAddress);
            cmd.Parameters.AddWithValue("@UserName", person.UuserName);


            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            int uID = Convert.ToInt32(reader[0].ToString());
            reader.Close();


            cmd.CommandText = "INSERT INTO[dbo].[Credentials]([PersonID],[Password])VALUES(@pID, @password);";
            cmd.Parameters.AddWithValue("@pID", uID);
            cmd.Parameters.AddWithValue("@password", person.UPassword);

            cmd.ExecuteNonQuery();
            
            conn.Close();

            return uID;
            
        }

        internal PersonShort CheckLogInCredentials(LogInCredentials lic)
        {

            PersonShort ps = new PersonShort();
            string connStr = configuration.GetConnectionString("myConnStr");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            string query = "SELECT Person.PersonID, Person.FName from [dbo].[Person]inner join[dbo].[Credentials] on Person.PersonID = Credentials.PersonID where Person.UserName = @userName AND Credentials.Password = @password;";
            SqlCommand cmd = new SqlCommand(query, conn);

            cmd.Parameters.AddWithValue("@userName", lic.UserName);
            cmd.Parameters.AddWithValue("@password", lic.UserPassword);

            SqlDataReader reader = cmd.ExecuteReader();

            reader.Read();
            
                ps = new PersonShort();
                ps.PersonID = reader["PersonID"].ToString();
                ps.FName = reader["FName"].ToString();
            
            conn.Close();
            return ps;
        }

        internal Person getPerson(int uID)
        {
            Person person = new Person();
            string connStr = configuration.GetConnectionString("myConnStr");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();


            string query= "SELECT [FName],[LName],[email],[phone],[address],[PersonID],[UserName]FROM [dbo].[Person] where PersonID = @uID;";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@uID", uID);

            
            SqlDataReader reader = cmd.ExecuteReader();

            reader.Read();

            person.UName = reader["FName"].ToString();
            person.ULast = (reader["LName"].ToString());
            person.UEmail = (reader["email"].ToString());
            person.UPhone = (reader["phone"].ToString());
            person.UAddress = (reader["address"].ToString());
            person.UuserName = (reader["UserName"].ToString());
            person.UID = uID;
            reader.Close();
            
            conn.Close();
            return person;
        }

        internal void UpdateUser(Person person)
        {

            string connStr = configuration.GetConnectionString("myConnStr");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();


            // string query = "UPDATE [dbo].[Person]SET [name] = @name,[city] = @city WHERE id =@id;";
            string query = "UPDATE [dbo].[Person] SET [FName] = @pfname,[LName] = @plname,[email] = @pEmail,[phone] = @pPhone,[address] = @paddress,[UserName] = @userName WHERE PersonID = @id;";
            
            SqlCommand cmd = new SqlCommand(query, conn);
           


            cmd.Parameters.AddWithValue("@pfname", person.UName);
            cmd.Parameters.AddWithValue("@plname", person.ULast);
            cmd.Parameters.AddWithValue("@pEmail", person.UEmail);
            cmd.Parameters.AddWithValue("@pPhone", person.UPhone);
            cmd.Parameters.AddWithValue("@pAddress", person.UAddress);
            cmd.Parameters.AddWithValue("@userName", person.UuserName);
            cmd.Parameters.AddWithValue("@id", person.UPersonId);

            
            
            //cmd.CommandText = "UPDATE [dbo].[Credentials] SET [PersonID] = @PersonID,[Password] = @Password WHERE [PersonID] = @PersonId;";
            //cmd.Parameters.AddWithValue("@Password", person.UPassword);
            cmd.ExecuteNonQuery();

            conn.Close();


        }

        internal void DeletePerson(int uID)
        {
            string connStr = configuration.GetConnectionString("myConnStr");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();


            // string query = "DELETE [dbo].[Person]SET [name] = @name,[city] = @city WHERE id =@id;";
            string query = "DELETE FROM[dbo].[Credentials] WHERE PersonID = @id;";

            SqlCommand cmd = new SqlCommand(query, conn);
            
            cmd.Parameters.AddWithValue("@id", uID);
           
            cmd.ExecuteNonQuery();

            cmd.CommandText = "DELETE FROM[dbo].[Person] WHERE PersonID =@id2";
            cmd.Parameters.AddWithValue("@id2", uID);

            cmd.ExecuteNonQuery();
            conn.Close();
            conn.Close();

        }

    }
}
