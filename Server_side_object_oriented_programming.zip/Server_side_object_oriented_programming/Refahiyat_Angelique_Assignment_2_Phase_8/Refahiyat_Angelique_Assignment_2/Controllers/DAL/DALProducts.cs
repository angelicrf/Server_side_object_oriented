﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Refahiyat_Angelique_Assignment_2.Controllers.DAL;
using Refahiyat_Angelique_Assignment_2.Models;
using System.Data.SqlClient;

namespace Refahiyat_Angelique_Assignment_2.Controllers.DAL
{
    public class DALProducts
    {
        public IConfiguration configuration;
        public DALProducts(IConfiguration config)
        {
            this.configuration = config;
        }

        public int AddNewProduct(Products products)
        {
            string connStr = configuration.GetConnectionString("MyConnStr");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            
            string querry = "INSERT INTO [dbo].[Products]([Name],[Description],[Price],[InventoryAmount]) VALUES(@Name,@Description,@price,@InventoryAmount) Select SCOPE_IDENTITY() as id;";
            SqlCommand cmd = new SqlCommand(querry, conn);
            cmd.Parameters.AddWithValue("@Name", products.Name);
            cmd.Parameters.AddWithValue("@Description", products.Description);
            cmd.Parameters.AddWithValue("@price", products.Price);
            cmd.Parameters.AddWithValue("@InventoryAmount", products.InventoryAmount);
            


            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            
            int pID = Convert.ToInt32(reader[0].ToString());
            
            

            conn.Close();

            return pID;

        }

        internal void UpdateInventory(int pID, int InventoryDelta)
        {
            string connStr = configuration.GetConnectionString("myConnStr");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            
            string querry = "UPDATE [dbo].[Products] SET [InventoryAmount] = InventoryAmount+@InventoryDelta WHERE PID = @pID; ";

            SqlCommand cmd = new SqlCommand(querry, conn);

            cmd.Parameters.AddWithValue("@InventoryDelta", InventoryDelta );
            cmd.Parameters.AddWithValue("@pID",pID);
       
            cmd.ExecuteNonQuery();

            conn.Close();
            

        }

        internal Products getProduct(int pID)
        {
            Products products = new Products();
            string connStr = configuration.GetConnectionString("myConnStr");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            
            string querry = "SELECT[Name],[Description],[PID],[Price],[InventoryAmount] FROM[dbo].[Products] where PID =@pID;";
            SqlCommand cmd = new SqlCommand(querry, conn);
            cmd.Parameters.AddWithValue("@pID", pID);


            SqlDataReader reader = cmd.ExecuteReader();

            reader.Read();
            Products p = new Products();

            products.Name = reader["Name"].ToString();
            products.Description = reader["Description"].ToString();
            products.Price = float.Parse(reader["Price"].ToString());
            products.InventoryAmount = Convert.ToInt32(reader["InventoryAmount"].ToString());
            products.PID = pID;


            reader.Close();
           
            conn.Close();
            return products;
        }

        
        public LinkedList<Products> GetAllProducts()
        {
           
            string connStr = configuration.GetConnectionString("myConnStr");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();


            string query = "SELECT * FROM [dbo].[Products];";

            SqlCommand cmd = new SqlCommand(query, conn);
            
            
            //Create a link List
            LinkedList<Products> prods = new LinkedList<Products>();

            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Products p = new Products();
                p.Description = reader["Description"].ToString();
                p.Name = reader["Name"].ToString();
                p.PID = Convert.ToInt32(reader["PID"].ToString());
                p.Price = float.Parse(reader["Price"].ToString());
                p.InventoryAmount = Convert.ToInt32(reader["InventoryAmount"].ToString());

                prods.AddLast(p);

            }

            conn.Close();
            return prods;
        }
    }
}
