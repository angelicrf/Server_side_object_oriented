﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Refahiyat_Angelique_Assignment_2.Models;
using Refahiyat_Angelique_Assignment_2.Models.DAL;
using System.Data.SqlClient;

namespace Refahiyat_Angelique_Assignment_2.Controllers.DAL
{
    public class DALSalesTransaction
    {
        private IConfiguration configuration;
        public DALSalesTransaction(IConfiguration config)
        {
            this.configuration = config;
        }

        
        public int RecordTransaction(int prodID, int personID)
        {
            string connStr = configuration.GetConnectionString("MyConnStr");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            string querry = "INSERT INTO [dbo].[SalesTransaction]([ProductID],[PersonID],[SalesDataTime],[PQuantity])VALUES(@prodID,@personID,GETDATE(),1) Select SCOPE_IDENTITY() as id;";
            SqlCommand cmd = new SqlCommand(querry, conn);
            cmd.Parameters.AddWithValue("@prodID", prodID);
            cmd.Parameters.AddWithValue("@personID", personID);
            

            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();

            int salestransactionid = Convert.ToInt32(reader[0].ToString());



            conn.Close();

            return salestransactionid;



        }
    }
}
