﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Refahiyat_Angelique_Assignment_2.Models
{
    public class SalesTransaction
    {
        public int ProductID  { get; set; }
        public int PersonID { get; set; }
        public int PQuantity { get; set; }
        public DateTime SalesDateTime { get; set; }
    }
}
