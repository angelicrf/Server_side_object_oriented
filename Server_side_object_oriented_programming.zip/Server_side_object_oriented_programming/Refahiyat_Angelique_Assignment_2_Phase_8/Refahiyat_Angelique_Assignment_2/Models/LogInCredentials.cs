﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Refahiyat_Angelique_Assignment_2.Models
{
    public class LogInCredentials
    {
        public string UserName { get; set; }
        public String UserPassword { get; set; }
    }
}
