﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Refahiyat_Angelique_Assignment_2.Models
{
    public class PersonShort
    {
        public String FName { get; set; }
        public String PersonID { get; set; }
    }
}
