﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Refahiyat_Angelique_Assignment_2.Models;

namespace Refahiyat_Angelique_Assignment_2.Models
{
    public class Person
    {
        public string UName { get; set; }
        public string ULast { get; set; }
        public string UAddress { get; set; }
        public string UEmail { get; set; }
        public string UPhone { get; set; }
        public string UuserName { get; set; }
        public string UCity { get; set; }
        public int UPersonId { get; set; }
        public string UPassword { get; set; }
        public int UID { get; set; }
    }
}
