﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Refahiyat_Angelique_Assignment_2.Models
{
    public class Products
    {
        public string Description { get; set; }
        public float Price { get; set; }
        public int InventoryAmount { get; set; }
        public int PID { get; set; }
        public string Name { get; set; }
    }
}
 